import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AuthenticationService } from '../authentication.service'
import { EqualValidator } from './password'


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';

  constructor(
      private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
      private authenticationService: AuthenticationService
  ) { }
  
  ngOnInit() {
      this.loginForm = this.formBuilder.group({
          username: ['',[ Validators.required,Validators.minLength(6)]],
          password: ['',[ Validators.required,Validators.minLength(8)]],
          mobile: ['',[ Validators.required,Validators.min(1000000000),Validators.max(9999999999)]],
          email: ['', Validators.required],
          name: ['', [Validators.required,Validators.minLength(6)]],
          cnfpassword: ['', [Validators.required,Validators.minLength(6)]]
      });

      // reset login status
      //this.authenticationService.logout();

      // get return url from route parameters or default to '/'
      this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }

  onSubmit() {

      this.submitted = true;

      // stop here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }

      this.loading = true;
      this.authenticationService.register(this.f.username.value, this.f.password.value,this.f.name.value,this.f.email.value,this.f.mobile.value)
          .pipe(first())
          .subscribe(
              data => {
                  console.log("Success")
                  this.router.navigate([this.returnUrl]);
              },
              error => {
                  alert("Username already exists");
                  this.loginForm.reset();
                  this.error = error;
                  this.loading = false;
              });
  }

}
