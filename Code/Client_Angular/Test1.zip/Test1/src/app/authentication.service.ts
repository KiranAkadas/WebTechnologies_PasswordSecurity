import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http:HttpClient) { 
    
  }

  register(username,password,name,email,mobile){
    //alert(username)
    return this.http.post<any>('http://localhost:3000/api/user',{username:username,password:password,email:email,name:name,mobile:mobile})
    .pipe(map(user=>{
      console.log(user);
      return user;
    }))
  }
  //this.loading = true;
    // this.authenticationService.login(this.f.username.value, this.f.password.value)
    //     .pipe(first())
    //     .subscribe(
    //         data => {
    //             this.router.navigate([this.returnUrl]);
    //         },
    //         error => {
    //             this.error = error;
    //             this.loading = false;
    //         });
  login(username,password){
    return this.http.post<any>('http://localhost:3000/api/user1',{username:username,password:password})
    .pipe(map(user=>{
      console.log(user);
      return user;
    }))
  }

}
