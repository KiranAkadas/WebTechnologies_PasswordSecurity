import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.error.html',
  styleUrls: ['./app.component.css']
})
export class ErrorComponent {
  title = 'client';
}
