import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.success.html',
  styleUrls: ['./app.success.css']
})
export class SuccessComponent {
  title = 'client';
}
